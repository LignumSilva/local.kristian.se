var nesApp = angular.module('nesApp', []);

nesApp.controller('NesListCtrl', function ($scope, $http) {
	$http.get('/list').success(function(data) {
		$scope.roms = data;
	});

	var pending = false;

	$scope.runRom = function(e)
	{
		if (pending)
		{
			alert("Easy lad! Im not done with your last request yet.")
			return;
		}

		pending = true;
		var rom = e.target.getAttribute("rom");
		$http.get('/run?rom=' + encodeURIComponent(rom)).success(
			function(data) {
				pending = false;
				alert("Started ROM\n" + rom);
			}
		);
	}

});