/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import game.Battlefield;
import game.Game;
import game.Player;
import game.Tank;
import game.TickTurns;
import game.Turn;
import java.awt.BasicStroke;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.ImageFilter;
import java.awt.Toolkit;
import java.awt.geom.Line2D;
import java.awt.image.BufferedImage;
import java.awt.image.RGBImageFilter;
import java.awt.image.Raster;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import org.json.JSONObject;

/**
 *
 * @author Martin
 */
public class Renderer {
	
	RendererPainter rendererPainter;
	ArrayList<TickTurns> tickTurnsArray;

	Image imgTankUp;
	Image imgTankDown;
	Image imgTankLeft;
	Image imgTankRight;
	
	public Renderer(Game game)
	{
		tickTurnsArray = new ArrayList();
		
	    JFrame f = new JFrame();
		f.setSize(512, 512);
		rendererPainter = new RendererPainter();
		f.add(rendererPainter);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);
		
		imgTankUp = new ImageIcon(this.getClass().getResource("/assets/images/tank_up.png")).getImage();
		imgTankDown = new ImageIcon(this.getClass().getResource("/assets/images/tank_down.png")).getImage();
		imgTankLeft = new ImageIcon(this.getClass().getResource("/assets/images/tank_left.png")).getImage();
		imgTankRight = new ImageIcon(this.getClass().getResource("/assets/images/tank_right.png")).getImage();
	}
	
	public synchronized void updateFrame(TickTurns tickTurns) {
		tickTurnsArray.add(tickTurns);
	}

	public synchronized void render() {
		for (TickTurns tt : tickTurnsArray) {
			try
			{
				Thread.sleep(500);
				rendererPainter.drawFrame(tt);
			}
			catch(Exception e)
			{
				System.out.println("ThreadInterrupted");
			}		
		}
	}
	
	
	public class RendererPainter extends JPanel {
		
		TickTurns tt;
	
		public RendererPainter()
		{
			super();
		}
		
		public void drawFrame(TickTurns tt)
		{
			this.tt = tt;
			this.updateUI();
		}		
		
		public Image colorTankImage(Image tankImg, int r, int b, int g) {
			BufferedImage img = new BufferedImage(16, 16, BufferedImage.TRANSLUCENT);
			Graphics2D graphics = img.createGraphics(); 
//			Color newColor = new Color(red, green, blue, 128 /* alpha needs to be zero */);
			//graphics.setXORMode(newColor);
			graphics.drawImage(tankImg, 0, 0, null);
			//graphics.drawImage(loadImg, null, 0, 0);

			//Raster r = img.getRaster();
			for(int i=0; i<16; i++){
				for(int j=0; j<16; j++){
					Color c = new Color(img.getRGB(j, i));
					int red = c.getRed();
					int green = c.getGreen();
					int blue = c.getBlue();
					int alpha = c.getAlpha();
					
					if (red == 217 && blue == 217 && green == 217)
					{
						red = r;
						green = g;
						blue = b;
					}
					else if (red == 0 && green == 255 && blue == 0)
					{
						alpha = 0;
						//System.out.println("X");
					}

					Color cNew = new Color(red, green, blue, alpha);
					img.setRGB(j, i, cNew.getRGB());
					//System.out.println("S.No: " + count + " Red: " + c.getRed() +"  Green: " + c.getGreen() + " Blue: " + c.getBlue());
				}
			}			
			graphics.dispose();
			
			return (Image)img;
		}		
		public void paint(Graphics graphics) {
			
			// Draw battle field, 16x16
			graphics.setColor(Color.white);
			
			//graphics.clearRect(0, 0, Battlefield.WIDTH, Battlefield.HEIGHT);
			graphics.fillRect(0, 0, Battlefield.WIDTH * Battlefield.WIDTH, Battlefield.HEIGHT * Battlefield.HEIGHT);
			graphics.setClip(0, 0, 1+ (Battlefield.WIDTH * Battlefield.WIDTH), 1 + (Battlefield.HEIGHT * Battlefield.HEIGHT));
			drawBattlefield(graphics);
			drawTanks(graphics);
		}
		
		public void drawBattlefield(Graphics g)
		{
			g.setColor(Color.gray);
			// Draw battle field, 16x16
			for (int y=0; y<Battlefield.HEIGHT; y++)
			{
				for (int x=0; x<Battlefield.WIDTH; x++)
				{
					g.setColor(Color.LIGHT_GRAY);
					g.drawRect (x * Battlefield.WIDTH, y * Battlefield.HEIGHT, Battlefield.WIDTH, Battlefield.HEIGHT);
				}
			}		
		}

		private void drawLaser(Graphics g, int a, int x0, int y0, int x1, int y1)
		{
			// todo: left and up are offseted one square to much
			Graphics2D g2 = (Graphics2D) g;
			g2.setStroke(new BasicStroke(4));
			g.setColor(Color.GREEN);
			
			int halfWidth = (Battlefield.WIDTH / 2);
			int halfHeight = (Battlefield.HEIGHT / 2);
			
			int rx0 = x0 * Battlefield.WIDTH;
			int rx1 = x1 * Battlefield.WIDTH;
			int ry0 = y0 * Battlefield.HEIGHT;
			int ry1 = y1 * Battlefield.HEIGHT;
			
			if (a == Tank.ANGLE_UP)
			{
				rx0 += halfWidth;
				rx1 += halfWidth;
				ry0 += Battlefield.HEIGHT;
				//g.drawLine(rx0-1, ry0, rx1-1, ry1);
			}
			else if (a == Tank.ANGLE_DOWN)
			{
				rx0 += halfWidth;
				rx1 += halfWidth;
				ry1 += Battlefield.HEIGHT;
				//g.drawLine(rx0-1, ry0, rx1-1, ry1);
			}
			else if (a == Tank.ANGLE_LEFT)
			{
				ry0 += halfWidth;
				ry1 += halfWidth;
				rx0 += Battlefield.WIDTH;
				//g.drawLine(rx0, ry0-1, rx1, ry1-1);
			}
			else if (a == Tank.ANGLE_RIGHT)
			{
				ry0 += halfWidth;
				ry1 += halfWidth;
				rx1 += Battlefield.WIDTH;
				//g.drawLine(rx0, ry0-1, rx1, ry1-1);
			}
			
			g.drawLine(rx0, ry0, rx1, ry1);
			
			g2.setStroke(new BasicStroke(1));
		}
		
		private void drawTank(Graphics g, int tick, int tx, int ty, int angle, int red, int green, int blue)
		{
			int x0 = tx * Battlefield.WIDTH;
			int y0 = ty * Battlefield.HEIGHT;

			System.out.println(tick + "] x0="+x0+" | y0="+y0+" | tx=" + tx + ", ty=" + ty);
			
			Image img = null;
			int offsx = 0;
			if (angle == Tank.ANGLE_RIGHT)
				img = imgTankRight;
			else if (angle == Tank.ANGLE_LEFT)
				img = imgTankLeft;
			else if (angle == Tank.ANGLE_UP)
				img = imgTankUp;
			else if (angle == Tank.ANGLE_DOWN)
				img = imgTankDown;
			
			Image tankImage = this.colorTankImage(img, red, green, blue);
			// Draw a the tank
			g.drawImage(tankImage, x0, y0, x0+16, y0+16, 0, 0, 16, offsx+16, this);
		}
		
		public void drawTanks(Graphics g)
		{
			if (tt == null)
				return;
			
			ArrayList<Turn> turns = tt.getTurns();
			for (Turn turn : turns) {
				JSONObject j = turn.getJSON();
				JSONObject jp = j.getJSONObject("player");
				JSONObject jt = jp.getJSONObject("tank");

				int tick = j.getInt("tick");
				int angle = jt.getInt("angle");
				int tx = jt.getInt("x");
				int ty = jt.getInt("y");
				int cr = jt.getInt("colorRed");
				int cg = jt.getInt("colorGreen");
				int cb = jt.getInt("colorBlue");
				
				drawTank(g, tick, tx, ty, angle, cr, cg, cb);
				if (jt.has("laser"))
				{
					JSONObject jl = jt.getJSONObject("laser");
					int laser_x0 = jl.getInt("x0");					
					int laser_y0 = jl.getInt("y0");
					int laser_x1 = jl.getInt("x1");
					int laser_y1 = jl.getInt("y1");
					int laser_a = jl.getInt("angle");
					drawLaser(g, laser_a, laser_x0, laser_y0, laser_x1, laser_y1);
				}
			}
		}
	}
}
