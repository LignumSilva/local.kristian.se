/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Webserver;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author Martin
 */
public class Config {
	
	private static boolean inited = false;
	private static JSONObject config;
	private static HashMap<String, HashMap<String, String>> extHandlers;
	
	final static String KEY_PORT = "port";
	final static String KEY_WWWROOT = "www-root";
	final static String KEY_ROMROOT = "rom-root";
	final static String KEY_EXTHANDLERS = "handlers";
	final static String KEY_EXTHANDLERS_CMD = "command";
	final static String KEY_EXTHANDLERS_CMDPATH = "path";
	final static String KEY_EXTHANDLERS_PARAMS = "params";

	
	public static boolean init(String configPath) {
    if (inited)
			return true;
		
		BufferedReader br = null;
    try {
				br = new BufferedReader(new FileReader(configPath));
        StringBuilder sb = new StringBuilder();
        String line = br.readLine();

        while (line != null) {
            sb.append(line);
            sb.append(System.lineSeparator());
            line = br.readLine();
        }
				config = new JSONObject(sb.toString());
				
				inited = true;
    }
		catch (JSONException ex) {
			System.err.println("Could read, but not parse config file.");
		}
		catch (Exception ex)
		{
			System.err.println("Could not read config file - aborted.");
		}
		finally {
			try {
				if (br != null)
		      br.close();
			}
			catch(Exception ex) {
				System.err.println("Could not close file stream.");
			}
    }
		
		if (inited)
			return true;
		
		return false;
	}
	
	public static Object get(String key)
	{
		if (!inited)
			return null;
		
		if (!config.has(key))
			return null;
		
		return config.get(key);
	}
	
	public static String getCommand(String ext)
	{
			JSONObject hs = config.getJSONObject(KEY_EXTHANDLERS);
			if (hs.has(ext))
				return hs.getJSONObject(ext).getString(KEY_EXTHANDLERS_CMD);

			return null;
	}
	public static String getCommandPath(String ext)
	{
			JSONObject hs = config.getJSONObject(KEY_EXTHANDLERS);
			if (hs.has(ext))
				return hs.getJSONObject(ext).getString(KEY_EXTHANDLERS_CMDPATH);

			return null;
	}	
	public static String getCommandParams(String ext)
	{
			JSONObject hs = config.getJSONObject(KEY_EXTHANDLERS);
			if (hs.has(ext))
				return hs.getJSONObject(ext).getString(KEY_EXTHANDLERS_PARAMS);

			return null;
	}

}
