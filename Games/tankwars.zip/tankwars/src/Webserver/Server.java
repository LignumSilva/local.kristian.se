/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Webserver;
import Webserver.handler.game.*;
import Webserver.handler.player.PlayerScriptHandler;
import game.Game;
import com.sun.net.httpserver.HttpServer;
import game.Player;
import game.Simulation;
import gui.Renderer;
import java.io.BufferedReader;
import java.io.FileReader;
import java.net.InetSocketAddress;
import java.util.HashMap;
import java.util.UUID;
import javax.swing.JFrame;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author martin
 */
public class Server {

	public static HashMap<UUID, Game> games;
	
	public static void main(String[] args) throws Exception {

		// TODO, use commandline args to override port
		int port = 8000;
		
		HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);
		GameHandler gh = new GameHandler();
		games = new HashMap();
		
		server.createContext("/game/list", new GameListHandler()).getFilters().add(new ParameterFilter());
		server.createContext("/game", new GameInfoHandler()).getFilters().add(new ParameterFilter());
		server.createContext("/game/join", new GameJoinHandler()).getFilters().add(new ParameterFilter());
		server.createContext("/game/leave", new GameLeaveHandler()).getFilters().add(new ParameterFilter());
		server.createContext("/game/create", new GameCreateHandler()).getFilters().add(new ParameterFilter());
		server.createContext("/game/ready", new GameReadyHandler()).getFilters().add(new ParameterFilter());
		server.createContext("/game/start", new GameStartHandler()).getFilters().add(new ParameterFilter());
		
		server.createContext("/player/script", new PlayerScriptHandler()).getFilters().add(new ParameterFilter());
		

		server.setExecutor(null); // creates a default executor
		server.createContext("/", new FileHandler());
		
		server.start();
		System.out.println("Server started using port " + port);

		
		
		// Testing
		Game g = new Game("Test game");
		Player p1 = new Player("Robin hood");
		g.addPlayer(p1);
		p1.setScript(readTestScript("d:\\test.js"));

		Player p2 = new Player("Megan fox");
		g.addPlayer(p2);
		p2.setScript(readTestScript("d:\\test2.js"));
		
		games.put(g.getId(), g);
		
		g = new Game("Sweden Tournament");
		games.put(g.getId(), g);
		
//p.setScript("function onTick(tickData) { return JSON.stringify({command:1,value:1}); } ");

		//Simulation sim = new Simulation(g);
		//sim.run();
	}
	
	
	public static String readTestScript(String path) {
		
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(path));
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();

			while (line != null) {
				sb.append(line);
				sb.append(System.lineSeparator());
				line = br.readLine();
			}
			return sb.toString();
		}
		catch (JSONException ex) {
			System.err.println("Could read, but not parse config file.");
		}
		catch (Exception ex)
		{
			System.err.println("Could not read config file - aborted.");
		}
		finally {
			try {
				if (br != null)
		      br.close();
			}
			catch(Exception ex) {
				System.err.println("Could not close file stream.");
			}
		}
		
		return null;
	}
}
