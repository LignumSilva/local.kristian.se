/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Webserver;

import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import game.Game;
import game.Player;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Map;
import java.util.UUID;
import org.json.JSONObject;

/**
 *
 * @author Martin
 */
public class GameHandler {

	

	
	// Join game info response, with parameter uuid
	
	
	// Handle creation of new game
}
