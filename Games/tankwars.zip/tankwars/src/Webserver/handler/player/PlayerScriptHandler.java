/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Webserver.handler.player;

import Webserver.RequestHelper;
import Webserver.Server;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import game.Game;
import game.Player;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.script.ScriptException;
import org.json.JSONObject;

/**
 *
 * @author Martin
 */
public class PlayerScriptHandler implements HttpHandler {
	public void handle(HttpExchange t) throws IOException {
		Map params = (Map)t.getAttribute("parameters");
		String uuidStr = (String)params.get("uuid"); // game uuid
		String playeruuidStr = (String)params.get("playeruuid"); // player uuid
		String script = (String)params.get("script"); // player script
		
		boolean res = false;
		JSONObject response = new JSONObject();			

		if (uuidStr != null)
		{ 
			UUID uuid = UUID.fromString(uuidStr);
			if (Server.games.containsKey(uuid))
			{
				Game g = Server.games.get(uuid);
				
				if (playeruuidStr != null)
				{
					UUID puuid = UUID.fromString(playeruuidStr);
					HashMap<UUID, Player> players = g.getPlayers();
					if (players.containsKey(puuid))
					{
						res = true;
						
						try {
							players.get(puuid).setScript(script);
							response.put("ack", true);
						} catch (ScriptException ex) {
							String str = ex.toString();
							
							response.put("error", "There was something wrong with your script:\n" + ex.getMessage());

							//Logger.getLogger(PlayerScriptHandler.class.getName()).log(Level.SEVERE, null, ex);
						}
					}
				}
			}
		}

		if (!res)
			response.put("error", "Player could not be found!");
		
		RequestHelper.sendJSONResponse(t, response);
	}
	
}
