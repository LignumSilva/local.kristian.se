/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Webserver.handler.game;

import Webserver.RequestHelper;
import Webserver.Server;
import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import game.Game;
import game.Player;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;

/**
 *
 * @author Martin
 */
public class GameCreateHandler implements HttpHandler {

	public void handle(HttpExchange t) throws IOException {
		Map params = (Map)t.getAttribute("parameters");
		String name = (String)params.get("name"); // game name
		String username = (String)params.get("username"); // player name
		Headers headers = t.getResponseHeaders();

		if (name == null)
			name = "New game";

		Game game = new Game(name);
		Player p = new Player(username);
		game.addPlayer(p);
		game.setOwner(p);
		Server.games.put(game.getId(), game);
		
		JSONObject res = game.getJSON();
		res.put("player", p.getPrivateJSON());
		
		RequestHelper.sendJSONResponse(t, res);
	}
}	
