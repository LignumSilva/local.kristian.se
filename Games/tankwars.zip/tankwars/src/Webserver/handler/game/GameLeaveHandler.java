/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Webserver.handler.game;

import Webserver.RequestHelper;
import Webserver.Server;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import game.Game;
import game.Player;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.json.JSONObject;

/**
 * TODO
 * @author Martin
 */
public class GameLeaveHandler implements HttpHandler {
	public void handle(HttpExchange t) throws IOException {
		Map params = (Map)t.getAttribute("parameters");
		String uuidStr = (String)params.get("uuid"); // game uuid
		String playeruuidStr = (String)params.get("playeruuid"); // player uuid
		
		JSONObject response = null;			
		if (uuidStr != null)
		{ 
			UUID uuid = UUID.fromString(uuidStr);
			if (Server.games.containsKey(uuid))
			{
				Game g = Server.games.get(uuid);
				
				if (!g.getStarted() && !g.getEnded() && playeruuidStr != null)
				{
					UUID puuid = UUID.fromString(playeruuidStr);
					HashMap<UUID, Player> players = g.getPlayers();
					if (players.containsKey(puuid))
					{
						Player p = players.get(puuid);
						players.remove(puuid);
						
						// last player, then quit the game.
						if (g.getPlayers().isEmpty()) {
							Server.games.remove(uuid);
						}
						// If owner leaves, end game.
						else if (p.getId() == g.getOwner().getId())
						{
							players.clear();
							Server.games.remove(uuid);
						}
					}
				}

				response = g.getJSON();			
			}
		}

		RequestHelper.sendJSONResponse(t, response);
	}
}
