/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Webserver.handler.game;

import Webserver.RequestHelper;
import Webserver.Server;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import game.Game;
import game.Player;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;
import org.json.JSONObject;

/**
 *
 * @author Martin
 */
public class GameJoinHandler implements HttpHandler {
	public void handle(HttpExchange t) throws IOException {
		Map params = (Map)t.getAttribute("parameters");
		String uuidStr = (String) params.get("uuid"); // game uuid
		//String scriptStr = (String) params.get("script");
		String nameStr = (String) params.get("username");

		JSONObject response = null;			
		if (uuidStr != null)
		{ 
			UUID uuid = UUID.fromString(uuidStr);
			if (Server.games.containsKey(uuid))
			{
				Game g = Server.games.get(uuid);
				if (g.getStarted() || g.getEnded())
				{
					RequestHelper.sendJSONError500Response(t, "Game already started, you cannot join.");
					return;
				}
				Player p = new Player(nameStr);
				g.addPlayer(p);
				response = g.getJSON();
				response.put("player", p.getPrivateJSON());
			}
		}

		RequestHelper.sendJSONResponse(t, response);
	}
}
