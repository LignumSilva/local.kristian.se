/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Webserver.handler.game;

import Webserver.RequestHelper;
import Webserver.Server;
import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import game.Game;
import game.Player;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.json.JSONObject;

/**
 *
 * @author Martin
 */
public class GameReadyHandler implements HttpHandler {

	public void handle(HttpExchange t) throws IOException {
		Map params = (Map)t.getAttribute("parameters");
		String uuidStr = (String) params.get("uuid"); // game uuid
		String playeruuidStr = (String) params.get("playeruuid"); // player uuid
		String ready = (String) params.get("ready"); // player uuid
		
		JSONObject response = null;			
		if (uuidStr != null)
		{ 
			UUID uuid = UUID.fromString(uuidStr);
			if (Server.games.containsKey(uuid))
			{
				Game game = Server.games.get(uuid);
				if (game.getStarted() || game.getEnded())
				{
					RequestHelper.sendJSONError500Response(t, "Game already started, you cannot change ready status.");
					return;
				}
				
				
				if (playeruuidStr != null)
				{
					UUID puuid = UUID.fromString(playeruuidStr);
					HashMap<UUID, Player> players = game.getPlayers();
					
					if (players.containsKey(puuid))
					{
						players.get(puuid).setReady("yes".compareTo(ready)==0);
					}
				}

				response = game.getJSON();			
			}
		}

		RequestHelper.sendJSONResponse(t, response);
	}
	
}	
