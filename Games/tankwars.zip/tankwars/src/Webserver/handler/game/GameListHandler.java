/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Webserver.handler.game;

	// Get game info response, with parameter uuid
import Webserver.RequestHelper;
import Webserver.Server;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import game.Game;
import java.io.IOException;
import java.util.Collection;
import org.json.JSONArray;
import org.json.JSONObject;


public class GameListHandler implements HttpHandler {

	public void handle(HttpExchange t) throws IOException {

		Collection<Game> gamelist = Server.games.values();
		
		JSONObject response = new JSONObject();
		JSONArray games = new JSONArray();
		response.put("games", games);
		
		for(Game game : gamelist)
		{
			games.put(game.getJSON());
		}

		RequestHelper.sendJSONResponse(t, response);
	}
}
