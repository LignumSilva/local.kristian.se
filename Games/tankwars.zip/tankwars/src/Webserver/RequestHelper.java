/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Webserver;

import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONObject;

/**
 *
 * @author Martin
 */
public class RequestHelper {
	public static HashMap<String, String> queryToMap(String query) {
		HashMap<String, String> result = new HashMap<String, String>();
		if (query == null)
			return result;
		
		for (String param : query.split("&")) {
			String pair[] = param.split("=");
			if (pair.length > 1) {
				result.put(pair[0], pair[1]);
			} else {
				result.put(pair[0], "");
			}
		}
		return result;
	}
	
	public static void sendJSONError500Response(HttpExchange t, String msg) throws IOException
	{
		Headers headers = t.getResponseHeaders();
		headers.add("Content-Type", "application/json");
		headers.add("Access-Control-Allow-Origin", "*");
		
		if (msg == null)
			msg = "Unknown error";

		t.sendResponseHeaders(500, msg.getBytes().length);
		OutputStream os = t.getResponseBody();
		os.write(msg.getBytes());
		os.close();		
	}
	
	public static void sendJSON404Response(HttpExchange t, JSONObject j) throws IOException
	{
		Headers headers = t.getResponseHeaders();
		headers.add("Content-Type", "application/json");
		headers.add("Access-Control-Allow-Origin", "*");
		
		String response = "{}";
		if (j != null)
			response = j.toString();			

		t.sendResponseHeaders(404, response.getBytes().length);
		OutputStream os = t.getResponseBody();
		os.write(response.getBytes());
		os.close();
		
	}
	
	public static void sendJSONResponse(HttpExchange t, JSONObject j) throws IOException
	{
		Headers headers = t.getResponseHeaders();
		headers.add("Content-Type", "application/json");
		headers.add("Access-Control-Allow-Origin", "*");
		
		String response = "{}";
		if (j != null)
			response = j.toString();			

		
		t.sendResponseHeaders(200, response.getBytes().length);
		OutputStream os = t.getResponseBody();
		os.write(response.getBytes());
		os.close();
	}
}
