package Webserver;

import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

class FileHandler implements HttpHandler {

	private String readFile(String path) throws FileNotFoundException, IOException {
		BufferedReader br = new BufferedReader(new FileReader(path));
		try {
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();

			while (line != null) {
				sb.append(line);
				sb.append(System.lineSeparator());
				line = br.readLine();
			}
			return sb.toString();
		} finally {
			br.close();
		}

	}

	// This is the file server part
	public void handle(HttpExchange t) throws IOException {
		String response = "404 Not found";
		String mimeType = null;
		byte[] bresp;
		try {
			String basePath = "/assets/html/";
			String path = t.getRequestURI().getPath();
			if (path.equals("/"))
				path = "index.html";
			
			//String filename = basePath + path;

			Path p = Paths.get(this.getClass().getResource(basePath + path).toURI());
			String filename = this.getClass().getResource(basePath + path).getFile();
			response = readFile(filename);
			bresp = Files.readAllBytes(p);//readFile(filename);
			
			if (filename.endsWith(".js"))
				mimeType = "application/javascript";
			else if (filename.endsWith(".html"))
				mimeType = "text/html";
			else if (filename.endsWith(".css"))
				mimeType = "text/css";
			else if (filename.endsWith(".png"))
				mimeType = "image/png";
			else if (filename.endsWith(".jpg"))
				mimeType = "image/jpeg";
			else if (filename.endsWith(".mp3"))
				mimeType = "audio/mpeg";
			else if (filename.endsWith(".ogg"))
			{
				mimeType = "audio/ogg";
			}
			
		} catch (Exception ex) {
			//String basePath = (String)Config.get(Config.KEY_WWWROOT);
			String filename = t.getRequestURI().getPath();
			
			response += ": " + filename + " => " + ex;
			t.sendResponseHeaders(404, response.getBytes().length);
						
			OutputStream os = t.getResponseBody();
			os.write(response.getBytes());
			os.close();

			return;
		}

		Headers headers = t.getResponseHeaders();
		if (mimeType != null)
			headers.add("Content-Type", mimeType);
		
//		Content-Length:1700011
//Content-Range:bytes 0-1700010/1700011	
		if ("audio/ogg".equals(mimeType) ||"audio/mp3".equals(mimeType))
		{
			headers.add("Accept-Ranges", "bytes");
			headers.add("Content-Range", "bytes 0-"  + bresp.length);
		}
		
		headers.add("Access-Control-Allow-Origin", "*");

		t.sendResponseHeaders(200, bresp.length);
		OutputStream os = t.getResponseBody();
		os.write(bresp);
		os.close();
		return;
		
	//	t.sendResponseHeaders(200, response.getBytes().length);

//		OutputStream os = t.getResponseBody();
//		os.write(response.getBytes());
//		os.close();
	}
}
