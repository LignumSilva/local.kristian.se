/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Webserver;

import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Martin
 */
public class ListHandler implements HttpHandler {

	public void handle(HttpExchange t) throws IOException {
		String response = "";
		try {
			String basePath = (String)Config.get(Config.KEY_ROMROOT);
			File folder = new File(basePath);
			File[] listOfFiles = folder.listFiles();
			JSONArray arr = new JSONArray();
			for (int i = 0; i < listOfFiles.length; i++) {
				if (listOfFiles[i].isFile()) {
					JSONObject obj = new JSONObject();
					String fname = listOfFiles[i].getName();
					obj.put("name", fname);
					obj.put("title", fname.substring(0, fname.lastIndexOf(".")));
					obj.put("path", fname.substring(0, fname.lastIndexOf(".")));

					arr.put(obj);
				}
			}

			response = arr.toString();

			Headers headers = t.getResponseHeaders();
			headers.add("Content-Type", "application/json");
			headers.add("Access-Control-Allow-Origin", "*");

			t.sendResponseHeaders(200, response.getBytes().length);
			OutputStream os = t.getResponseBody();
			os.write(response.getBytes());
			os.close();
		} catch (Exception ex) {
			System.out.println("err:" + ex);
		}
	}
}
