var preload = null;
var TESTMODE = true;

gameControllers.controller('GameLobbyCtrl', function ($scope, $routeParams, $http) {
	
	if (gameSettings.username == null)
	{
		location.href = "/";
		return;
	}
	
    $scope.gameId = $routeParams.gameId;
	$scope.playerId = gameSettings.playerUUID;
	$scope.hasJoined = false;

	$scope.player = null;
	$scope.playerScript = "";
	gameSettings.playerUUID = null;
	
	if(renderer == null)
		renderer = new Renderer(document.getElementById('gamecanvas'), SAMPLE_GAME_DATA);
		
	if ($scope.playerId == null)
	{
			var params = {};
			params.uuid = $scope.gameId;
			params.username = gameSettings.username;
		
		// no player id yet, join
		$http({
			method: 'POST',
			url: "game/join",
			headers: {'Content-Type': 'application/x-www-form-urlencoded'},
			transformRequest: transformPostRequest,
			data: params
		}).success(function (data) {
			$scope.game = data;
			$scope.player = data.player;			
			$scope.hasJoined = true;

		}).error(function (data) {
			alert("Failed to join game.");
		});			
	}
	else
	{
		// Allready got player id
		$http.get('game/?uuid=' + $scope.gameId + ($scope.playerId!=null?"&playeruuid="+$scope.playerId:"")).success(function(data) {
			$scope.game = data;
			$scope.player = data.player;
			console.log("Game: ", data);
						
		}).error(function (data) {
			alert("Failed to join game.");
		});
	}
	
	$scope.leaveGame = function(e)
	{
		var params = {};
		params.uuid = $scope.gameId;
		params.playeruuid = $scope.player.uuid;

		$http({
			method: 'POST',
			url: "game/leave",
			headers: {'Content-Type': 'application/x-www-form-urlencoded'},
			transformRequest: transformPostRequest,
			data: params
		}).success(function (data) {
			$scope.game = data;
			$scope.player = null;
			location.href = "#/list";
		}).error(function (data) {
			location.href = "#/list";
			//alert("Failed to leave game.");
		});
	};
	
	$scope.renderGame = function(game)
	{
		var r = new Renderer(document.getElementById('gamecanvas'), game);
	}
	
	$scope.setReady = function(ready)
	{
		var params = {};
		params.uuid = $scope.gameId;
		params.playeruuid = $scope.player.uuid;
		params.ready = (ready==true?"yes":"no");
		
		$http({
			method: 'POST',
			url: "game/ready",
			headers: {'Content-Type': 'application/x-www-form-urlencoded'},
			transformRequest: transformPostRequest,
			data: params
		}).success(function (data) {
			$scope.game = data;
		}).error(function (data) {
			console.log("failed to set ready", data);
		});
	};	
	
	$scope.startGame = function(ready)
	{
		var params = {};
		params.uuid = $scope.gameId;
		params.playeruuid = $scope.player.uuid;
		
		$http({
			method: 'POST',
			url: "game/start",
			headers: {'Content-Type': 'application/x-www-form-urlencoded'},
			transformRequest: transformPostRequest,
			data: params
		}).success(function (data) {
			$scope.game = data;
		}).error(function (data) {
			console.log("failed to set ready", data);
		});
	};		
	
	$scope.pollServer = function() {
		$http.get('game/?uuid=' + $scope.gameId + ($scope.player.uuid!=null?"&playeruuid="+$scope.player.uuid:"")).success(function(data) {
			$scope.game = data;
			if (TESTMODE)
				$scope.game = SAMPLE_GAME_DATA;
			
			if ($scope.game != null && $scope.game.results != null && $scope.game.results.length > 0)
			{
				clearInterval(gameSettings.pollerInterval);
				$scope.renderGame($scope.game);
			}			
		}).error(function (data) {
			$scope.canStart = data.canStart;
			console.log("failed to poll server info", data);
			location.href = "#/list";
		});
	};
	
	$scope.sendScript = function(e)
	{
		if ($scope.player == null)
		{
			alert("Join the game first");
			return;
		}
		
		var params = {};
		params.uuid = $scope.gameId;
		params.playeruuid = $scope.player.uuid;
		params.script = $scope.playerScript;

		$http({
			method: 'POST',
			url: "player/script",
			headers: {'Content-Type': 'application/x-www-form-urlencoded'},
			transformRequest: transformPostRequest,
			data: params
		}).success(function (data) {
			console.log("Script res", data);
			if (data != null && data.error != null)
				alert(data.error);
			else
				alert("Script uploaded.");
		}).error(function (data) {
			alert("Failed to send script to server.");
		});			

	};	
	
	
	if (gameSettings.pollerInterval != null)
		clearInterval(gameSettings.pollerInterval);
	
	gameSettings.pollerInterval = setInterval($scope.pollServer, 1000);
  
});