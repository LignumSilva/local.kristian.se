var gameApp = angular.module('gameApp', [
  'ngRoute',
  'gameControllers'
]);

var gameSettings = {
	username : null,
	playerUUID : null,
	pollerInterval : null
};

gameApp.config(['$routeProvider',
  function($routeProvider) {
    $routeProvider.
      when('/list', {
        templateUrl: 'partials/list.html',
        controller: 'GameListCtrl'
      }).
      when('/login', {
        templateUrl: 'partials/login.html',
        controller: 'GameLoginCtrl'
      }).
      when('/game/:gameId', {
        templateUrl: 'partials/lobby.html',
        controller: 'GameListCtrl' // todo game ctrl instead
      }).
      when('/game/:gameId', {
        templateUrl: 'partials/lobby.html',
        controller: 'GameListCtrl' // todo game ctrl instead
      }).			  
      otherwise({
        redirectTo: '/login'
      });
  }]);
  
  
  var gameControllers = angular.module('gameControllers', []);
  
  
function transformPostRequest (obj) {
	var str = [];
	for(var p in obj)
		str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
	return str.join("&");
}