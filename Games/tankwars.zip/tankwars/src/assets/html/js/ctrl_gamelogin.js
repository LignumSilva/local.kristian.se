var renderer = null;
gameControllers.controller('GameLoginCtrl', function ($scope, $http) {
	$scope.usernameInput = 'T-Rex 2147';
	gameSettings.playerUUID = null;
	
	if (gameSettings.pollerInterval != null)
		clearInterval(gameSettings.pollerInterval);
	
	//if(renderer == null)
	//	renderer = new Renderer(document.getElementById('canvas'), SAMPLE_GAME_DATA);

	
	$scope.setUsername = function(e)
	{
		var name = $scope.usernameInput.trim();
		if (name.length === 0)
		{
			alert("You must enter a nickname");
			return;
		}
		
		gameSettings.username = name;
		location.href = "#/list";
	};	
});