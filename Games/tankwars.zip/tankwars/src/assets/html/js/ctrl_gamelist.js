gameControllers.controller('GameListCtrl', function ($scope, $http) {
	
	if (gameSettings.username == null)
	{
		location.href = "/";
		return;
	}

	if (gameSettings.pollerInterval != null)
		clearInterval(gameSettings.pollerInterval);

	
	$http.get('game/list').success(function(data) {
		$scope.games = data.games;
		console.log("Games: ", data.games);
	});

	$scope.joinGame = function(id)
	{
		location.href = "#/game/" + id;
	};

	$scope.newGame = function(e)
	{
		var gameName = prompt("Please enter game name", "New game");
		if (gameName.length === 0)
		{
			alert("You must enter a game name");
			return;
		}
		
		$http({
			method: 'POST',
			url: "game/create",
			headers: {'Content-Type': 'application/x-www-form-urlencoded'},
			transformRequest: transformPostRequest,
			data: {name:gameName, username:gameSettings.username}
		}).success(function (data) {
			console.log("ASDASD", data);
			var id = data.id;
			//$scope.joinGame(id);
			gameSettings.playerUUID = data.player.uuid;
			location.href = "#/game/" + id;
			console.log("Created new game: ", data);
		}).error(function (data) {
			alert("Failed to create new game.");
		});
	};
	
	$scope.pollGameList = function() {
		$http.get('game/list').success(function(data) {
			console.log("gamelist", data);
			$scope.games = data.games;
		});		
	};
	
	gameSettings.pollerInterval = setInterval($scope.pollGameList, 1000);
});
