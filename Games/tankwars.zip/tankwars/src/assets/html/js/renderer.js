// http://opengameart.org/content/dungeon-crawl-32x32-tiles
var groundImage = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH3wUcDAMrcxgw6gAAAB1pVFh0Q29tbWVudAAAAAAAQ3JlYXRlZCB3aXRoIEdJTVBkLmUHAAAEjUlEQVRYw3VXP3b6PBCcQAp1qHSHSjpUukMddPYNOAJX4AjJDfAN4AZ2mc50Tid3Tqd0SpWv+N4oK8OP93gY/d3dmZ1dv1wul18ACCEAALTW+NcnhPB0/tlejslxOcbxZV3XZ6016rqG1hoxRsQYobXG4XCAUgpFUSDGiBAClFKw1qIsSyilME0TYoxwzqEsS8QYAQDWWhhjktGHwwFaa4QQUJYljDGIMWLpnDvXdY22bRFCePDSe48QArz30FrDGINpmpIxvJC/wzBAKQXvPWKMyXjvPYwxAJD2O+ew4CWc5CXGGHjv01drnTzgsxyn0cfjMa2RZ4YQ0Pc9jDFpbd/3fwbQImLlvQeAZAzXzfEMIaT5EAKapsnmQgjY7XYP3KFRr/TEGIO+75+SylqL1WqF9/f3p2SjsbzQWptFpeu6FLG+72GtTfsWAOCce/DMOZcM8t5jHMdEKsLDdYSJc7vdLoW8bdt0Me+QsL7SI4mn9x6XyyXhxQhZa9MB0mNCwLHb7ZaFW0aXoSdPXp/lPg2hx3P857lNw9brNbquy0gtyeecQ9u2uQ445868jJdYa1P6MGWYSsx9ACiKInkDAB8fH1BKpf8xRiilktfcp7WGcw7DMPxlwRwjmR0hBByPxywNJQQylekE90oyEnsAaNsWzjksD4fDWUokraQiTtMErTXGccwUjJ5WVYX7/Q6tNaZpSuNShMqyTJGkE0VRYJqm/9OwruvMW6n7xNJam7GX2DdN88Cdtm0z/WB0JS/4u3hGPhrCnNVao+/7tLGqqizskpxztZPnymcSd+mcO1O3OVgUBYZhAABsNpsUHaUUlFL4+fnJilSMEcYYDMOQPFVKoe/7VCNIRq7neS+Xy+WX4X2WYnONmOf1vEwzdRl26bGMIvcs/lXT5/lPTCXTeQhLryw6vJj1hdVWQgEAixBCJg7e+wTFvCwzXaWxcny322UGz7kjHUoGzMlHa/khCVnVqqp66Gx4RtM0mYKyJkhJl+qptcaCaUj85qGTdeD7+zuVW4aT9R/Awzm32y1VPWMMTqdTSsXr9foXAYZFVrHVapUVGu89rtdrsp4wSR2QkZGawvQcx/Eh1V/e3t5+58SYy6fslHgY4WnbNmO5hLKqqhQFeZ6sqq/ywmf1milHLZg3IsR7vV4nw7hnHMesJNNYSeKFJI33PjUQXEiLaRxJOJ+f937MANn9kFcSosX8MOdcpv/GGGy328TipmkyTaf35ILUEUaCDkjHkhDJDc65jGQ0ij2dvKCqKjCDOC87JEZAGiPVkp+lc+5MLZ+mCZvNJhFtmqZUYvmyQvy+vr6y/l9rDaUUyrJMNeFZMWIp5vrXZ+02OcFn6ZE0QpZpjkkZlhGT2bTdbjGO418WsAPmGxIXn04n3O/3xGCZdoRMhnle1GThmb9pJSmWuFCC6QG7W1n5pFrOpZjpKjGWBnnvUdd14k/f938Q0KqqqtB1XcZy+SolO1syXHZTUvMlrHVdg4VPnpm64qIosN/v0XVd1tWyv+Oz7GxJQjYq/LLZ2O/3+Pz8TL0lCS259h8CRKSc/EbqugAAAABJRU5ErkJggg==";

var TANK_COMMAND_FIRE = 0;
var TANK_COMMAND_MOVE = 1;
var TANK_COMMAND_ROTATE = 2;
var SOUND_SHOOT = 1;
var SOUND_LOBBY_MUSIC = 2;

var TICK_LENGTH = 300;//500;
var TICK_PAUSE = 50;//100;

var soldierSpriteSheet = null;
var playerSprites = {
	
};

// TODO Add explosion for tank.laser.x1, tank.laser.y1
function Renderer (canvas, game)
{
	this.squareSize = 32;
	this.gameWidth = 16;
	this.gameHeight = 16;
	this.game = game;
	
	var stage = this.stage = new createjs.Stage(canvas);
	this.setupSpriteSheets();
	
	this.drawBattlefield();
	this.setupPlayers(game.players);

	//this.drawTank(0,0,0);
	//this.drawTank(90,1,1);
	//this.drawTank(90,1,2);

	//this.drawTank(180,2,2);
	//this.drawTank(270,3,3);
	createjs.Ticker.setFPS(60);
	createjs.Ticker.addEventListener("tick", stage);

	if (!createjs.Sound.initializeDefaultPlugins()) {
		// show some error..
		console.log("sound fail");
	}
	else {
		console.log("Sound plugins intited OK");
	}
	var sounds = [
		{src: "sound/bg.ogg", id: SOUND_LOBBY_MUSIC},
		{src: "sound/shoot.mp3", id: SOUND_SHOOT}
	];
	
	createjs.Sound.alternateExtensions = ["mp3"];	// add other extensions to try loading if the src file extension is not supported

	var self = this;
	var soundCount = 0;
	createjs.Sound.addEventListener("fileload", function(a,b,c) {
		
		console.log("Sound was loaded!");
		soundCount++;
		if (soundCount == sounds.length)
		{
			var instance = createjs.Sound.play(SOUND_LOBBY_MUSIC);
			instance.volume = 0.4;
			
			self.runGameResults(0);
			
		}
		//self.runGameResults(0);

	});	
	
	createjs.Sound.registerSounds(sounds);	
	console.log("Renderer ctor DONE");

}

function playSound(ev) {
	instance = createjs.Sound.play(ev.src);
}

Renderer.prototype.playSound = function (targetId) {
	console.log("========================> PLAYSOUND");
	//Play the sound: play (src, interrupt, delay, offset, loop, volume, pan)
	var instance = createjs.Sound.play(targetId);
};

Renderer.prototype.runGameResults = function(t) {
	
	var results = this.game.results;
	var self = this;

	if (t>=results.length)
	{
		for (var i in playerSprites)
		{
			playerSprites[i].sprite.gotoAndStop("walk");
		}
		return;
	}

	// moves
	var tween = null;
	var playerCountLeft = 0;
	var lastPlayerInLoop = null;
	for (var m=0; m<results[t].length; m++)
	{
		var move = results[t][m];
		var command = move.command;
		var value = move.value;
		var player = move.player;
		var img = null;
		var playerKey = ("p" + player.id);
		if (playerKey in playerSprites)
		{
			img = playerSprites[playerKey].sprite; 
			var newX = (player.tank.x * this.squareSize) + (this.squareSize / 2);
			var newY = (player.tank.y * this.squareSize) + (this.squareSize / 2);
			var newAngle = player.tank.angle;
			
			if (t == 0)
			{
				console.log("t0, init");
				img.x = newX;
				img.y = newY;
				img.rotation = newAngle;
			}
			var ph = document.getElementById("ph_" + player.id);
			if (ph)
				ph.innerHTML = (player.tank.health>0?player.tank.health:"dead");
			
			tween = createjs.Tween.get(img, {loop: false});

			var rot = newAngle;
			var tweenData = {};
			if (player.tank.health == 0) {
				img.gotoAndPlay("empty");
				continue;
			}
			
			playerCountLeft++;
			lastPlayerInLoop = player;
			if (command == TANK_COMMAND_FIRE)
			{
				img.gotoAndPlay("shoot");
			}
			else if (command == TANK_COMMAND_ROTATE)
			{
				img.gotoAndPlay("stand");
				//rot = img.rotation + value;
				tweenData.rotation = newAngle;
				
				console.log("Rotate offset=", value, "current A=",img.rotation, "target A=", rot);
			}
			else if (command == TANK_COMMAND_MOVE) {
				img.gotoAndPlay("walk");
				tweenData = {x:newX, y:newY};
			}

			tween = tween.to(tweenData, TICK_LENGTH);
			console.log(t + "] " + player.name + "hp=" +player.tank.health + "/5, x=" + player.tank.x + ", y=" + player.tank.y + " a=" + img.rotation);
			
			
			if (player.tank.laser)
			{
				console.log("LAZER", player.tank.laser);
				var imgE = new createjs.Sprite(soldierSpriteSheet, "explosion_run");
				imgE.x = player.tank.laser.x1 * this.squareSize;
				imgE.y = player.tank.laser.y1 * this.squareSize;
				this.stage.addChild(imgE);
				imgE.gotoAndPlay("explosion_run");
				this.playSound(SOUND_SHOOT);
			}

/*
			if (!cbSet)
			{
				tween.call(function() {
					self.runGameResults(results, t+1);
				});
				cbSet = true;
			}
			*/
		}
		
	}
	
	if (playerCountLeft == 1)
	{
		if (tween != null)
		{
			tween.wait(500).call(function() {
				document.getElementById("winnerName").innerHTML = lastPlayerInLoop.name;
				document.getElementById("winnerBanner").style.display = "block";
				setTimeout(function() {
					location.href = "/";
				},60000);
				//alert("Winner: " + lastPlayerInLoop.name);
				//location.href = "/";
			});
			
		}
		else  {
			//alert("Winner: " + lastPlayerInLoop.name);
			//location.href = "/";
		}
		return;
	}
	
	if (tween != null)
	{
		tween.wait(TICK_PAUSE).call(function() {
			self.runGameResults(t+1);
		});
	}
	
};

Renderer.prototype.setupPlayers = function(playersArray) {

	//playersArray = [ {id:1, tank: {x:1,y:1,a:90}, {id:2}, {id:3}];
	for (var p=0; p<playersArray.length; p++)
	{
		var player = playersArray[p];
		var img = new createjs.Sprite(soldierSpriteSheet, "empty");

		playerSprites["p" + player.id] = player;		
		playerSprites["p" + player.id].sprite = img;
		
		//var img = new createjs.Bitmap(tankImage);
		img.x = player.tank.x * this.squareSize;
		img.y = player.tank.y * this.squareSize;
		img.rotation = player.tank.angle;
		img.regX = img.regY = this.squareSize/2;
		img.x += this.squareSize/2;
		img.y += this.squareSize/2;
/*
		createjs.Tween.get(img, {loop: true})
		  .to({x: (x+1) * this.squareSize}, 1000)
		  .to({rotation:-90}, 500)
		  .to({x: x * this.squareSize}, 1000).call(function() {
			//console.log("derp");
			img.gotoAndPlay("shoot");
		  })
		  .to({rotation:90} , 500);
*/
		this.stage.addChild(img);
	}
};

Renderer.prototype.setupSpriteSheets = function() {
	var walkSpeed = 0.1;
	var shootSpeed = 0.1;
	
	soldierSpriteSheet = new createjs.SpriteSheet({
		images: [SOLDIER_SPRITE], 
		frames: { width: 32, height: 32 }, 
		animations: { // u, l, d, r
			stand : 0,/*
			stand_left : 5,
			stand_down : 10,
			stand_right : 15,
			*/
			empty : 31,
			explosion_done : 31,
			explosion_run : {
				frames : [31,31,31,31,31,32,33,34,35, 36,37,38,39, 40,41,42,43, 44,45,46,47], speed : 1, next:"explosion_done"
			},
			walk : {
				frames : [0,1,2,3], speed: walkSpeed
			},/*
			walk_left : {
				frames : [5,6,7,8], speed: walkSpeed
			},			
			walk_down : {
				frames : [10,11,12,13], speed: walkSpeed
			},
			walk_right : {
				frames : [15,16,17,18], speed: walkSpeed
			},*/
			shoot : {
				frames : [21,20,20], speed: shootSpeed, next:"stand"//, next : "stand_up"
			}/*,
			shoot_left : {
				frames : [23,24,23,23], speed: shootSpeed, next : "stand_left"
			},
			shoot_down : {
				frames : [26,27,26,26], speed: shootSpeed, next : "stand_down"
			},
			shoot_right : {
				frames : [29,30,29,29], speed: shootSpeed, next : "stand_right"
			}*/
		}
	});	

};

Renderer.prototype.drawBattlefield = function() {
	//this.stage = new createjs.Stage(canvas);
	for (var y=0; y<this.gameHeight; y++)
	{
		for (var x=0; x<this.gameWidth; x++)
		{
			var img = new createjs.Bitmap(groundImage);
			img.x = x * this.squareSize;
			img.y = y * this.squareSize;
			img.regX = 0;
			img.regY = 0;
			this.stage.addChild(img);
		}
	}
};

Renderer.prototype.drawTank = function(a, x, y) {
	return;
	var img = new createjs.Sprite(soldierSpriteSheet, "walk");
	//var img = new createjs.Bitmap(tankImage);
	img.x = x * this.squareSize;
	img.y = y * this.squareSize;
	img.rotation = a;
	img.regX = img.regY = this.squareSize/2;
	
	createjs.Tween.get(img, {loop: true})
	  .to({x: (x+1) * this.squareSize}, 1000)
	  .to({rotation:-90}, 500)
	  .to({x: x * this.squareSize}, 1000).call(function() {
		//console.log("derp");
		img.gotoAndPlay("shoot");
	  })
	  .to({rotation:90} , 500);
	
	this.stage.addChild(img);
};
