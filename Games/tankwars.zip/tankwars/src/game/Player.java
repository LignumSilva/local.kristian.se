/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import java.util.Date;
import java.util.UUID;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import org.json.JSONObject;

/**
 *
 * @author Martin
 */
public class Player implements Comparable {
	public static final long PLAYER_TIMEOUT = 10000;
	private static int _id = 0;
	private UUID uuid;
	private long id;
	private long lastPing;
	private String name;
	private String script = "";
	private Tank tank;
	private int score;
	private boolean ready = false;
	ScriptEngineManager scriptFactory = null;
	ScriptEngine scriptEngine = null;

	public Player(String name)
	{
		this.name = name;
		this.uuid = UUID.randomUUID();	
		this.tank = new Tank(this);
		this.score = 0;
		this.id = _id++;
		scriptFactory = new ScriptEngineManager();
		scriptEngine = scriptFactory.getEngineByName("JavaScript");
		
		ping();
	}

	public Tank getTank() {
		return tank;
	}
	
	public void ping() {
		lastPing = (new Date()).getTime();
	}
	public long getLastPing() {
		return lastPing;
	}
	
	public void setReady(boolean ready)
	{
		this.ready = ready;
	}
	public boolean getReady()
	{
		return this.ready;
	}
		
	public void setScript(String script) throws ScriptException
	{
		// prepare script
		this.script = script;
		scriptFactory = new ScriptEngineManager();
		scriptEngine = scriptFactory.getEngineByName("JavaScript");			
		scriptEngine.eval(script);
	}
	
	public JSONObject tick(Game game) {
		try {
			String jsonTickData = "{}";
			JSONObject bfd = game.getBattleFieldData();
			bfd.put("playerInfo", this.getJSON());
			jsonTickData = bfd.toString();
			String ret = (String)scriptEngine.eval("onTick(" + bfd + ");");
			JSONObject j = new JSONObject(ret);
			return j;
		}
		catch(Exception ex) {
			System.out.println("Failed to run player script. " + ex.toString());
		}	
		
		return null;
	}
	
	public UUID getUUID() {
		return uuid;
	}
	public long getId() {
		return id;
	}

	public String getName() {
		return name;
	}
	
	public JSONObject getJSON() {
		JSONObject obj = new JSONObject();
		obj.put("name", name);
		obj.put("id", id);
		obj.put("ready", ready);
		obj.put("tank", tank.getJSON());
		
		return obj;
	}
	
	public JSONObject getPrivateJSON() {
		JSONObject obj = new JSONObject();
		obj.put("name", name);
		obj.put("id", id);
		obj.put("uuid", uuid);
		return obj;
	}

	@Override
	public int compareTo(Object o) {
		if (o instanceof Player)
			return uuid.compareTo(((Player)o).getUUID());
		
		return 0;
	}
	
	@Override
	public String toString() {
		return "[player, id=" + id + ", name=" + name + "]";
	}
	
}
