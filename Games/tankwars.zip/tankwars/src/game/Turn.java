package game;

import game.command.ICommand;
import org.json.JSONObject;

/**
 *
 * @author Martin
 */
public class Turn {

	private JSONObject jsonObj;
	
	public Turn(long tick, Player player, int commandAction, int commandValue) {
		jsonObj = new JSONObject();
		jsonObj.put("tick", tick);
		jsonObj.put("player", player.getJSON());
		jsonObj.put("command", commandAction);
		jsonObj.put("value", commandValue);
	}
	
	public JSONObject getJSON()
	{
		return jsonObj;
	}
}
