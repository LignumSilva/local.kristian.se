package game;

import java.util.ArrayList;
import java.util.Date;
import java.util.Random;
import org.json.JSONObject;

/**
 *
 * @author Martin
 */
public class Tank {
	
	public static final int ANGLE_UP = 0;
	public static final int ANGLE_RIGHT = 90;
	public static final int ANGLE_DOWN = 180;
	public static final int ANGLE_LEFT = 270;
	
	private int ammo = 5;
	private int x = 0;
	private int y = 0;
	private long angle = 0;
	private int health = 5;
	private int lastTick = -1;
	
	private int colorRed = 255;
	private int colorBlue = 255;
	private int colorGreen = 255;
	
	//private ArrayList<Projectile> projectiles;
	private Laser laser = null;
	
	private Player player;
	private boolean dead = false;

	public Tank(Player player) {
		this.player = player;
		reset();
	}
	
	@Override
	protected void finalize() throws Throwable {		
		player = null;
		laser = null;
		super.finalize();
	}
	
	public int getNormalizedAngle() {
		long a = this.angle;
		
		if (a < 0)
		{
			return (int)(360 - (Math.abs(a) % 360)) % 360;
		}
		else 
			return (int)(a % 360);
	}
	
	public void reset() {
		Random r = new Random((new Date()).getTime());
		ammo = 50;
		x = r.nextInt(Battlefield.WIDTH);
		y = r.nextInt(Battlefield.HEIGHT);
		angle = 0;//r.nextInt(3) * 90; // 0,90,180,270
		health = 5;
		dead = false;
		colorRed = 255;
		colorBlue = 255;
		colorGreen = 255;
		
		resetLaser();
		//projectiles = new ArrayList();
	}
	
	public void setColor(int r, int g, int b)
	{
		colorRed = r;
		colorGreen = g;
		colorBlue = b;
		System.out.println("Setting tank color " + r + "," + g + "," + b);
	}
	
	public JSONObject getJSON() {
		JSONObject obj = new JSONObject();
		obj.put("ammo", ammo);
		obj.put("x", x);
		obj.put("y", y);
		obj.put("angle", angle);
		obj.put("health", health);
		obj.put("dead", dead);
		
		obj.put("colorRed", colorRed);
		obj.put("colorGreen", colorGreen);
		obj.put("colorBlue", colorBlue);
		
		
		if (laser != null)
			obj.put("laser", laser.getJSON());
		
		return obj;
	}
	
	public void updateDeadStatus() {
		if (health <= 0)
			dead = true;
	}
	
	public void tick() {
		lastTick++;
	}
	
	public boolean isDead() {
		return dead; 
	}
	
	public void setHit(Laser laser) {
		if (laser != null)
		{
			laser.setXTarget(this.getX());
			laser.setYTarget(this.getY());
		}
		
		health--;
	}
	
	public int getAmmo() {
		return ammo;
	}
	
	public boolean shoot() {
		if (ammo > 0)
		{
			laser = new Laser(this);
			return true;
			//Projectile p = new Projectile(this);
			//projectiles.add(p);
		}
		return false;
	}
	
	public Laser getLaser() {
		return laser;
	}
	
	public void resetLaser() {
		laser = null;
	}

	public void setAmmo(int ammo) {
		this.ammo = ammo;
	}

	public int getX() {
		
		return x;
	}

	public void setX(int x) {
		//System.out.println("MOVE TANK X FROM: " + this.x + " => " + x);
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		//System.out.println("MOVE TANK Y FROM: " + this.y + " => " + y);
		this.y = y;
	}

	public long getAngle() {
		return angle;
	}

	public void setAngle(long angle) {
		this.angle = angle;
	}

	public int getHealth() {
		return health;
	}

	public void setHealth(int health) {
		this.health = health;
	}
}
