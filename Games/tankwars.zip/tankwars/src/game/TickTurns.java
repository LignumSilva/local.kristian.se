/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import java.util.ArrayList;

/**
 * collection of turns in a tick.
 * @author Martin
 */
public class TickTurns {
	
	private int tick;
	private ArrayList<Turn> turns;
	public TickTurns(int tick) 
	{
		this.tick = tick;
		turns = new ArrayList();
	}
	
	public void add(Turn turn) {
		turns.add(turn);
	}
	
	public ArrayList<Turn> getTurns() {
		return turns;
	}
}
