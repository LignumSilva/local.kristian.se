/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

/**
 *
 * @author Martin
 */
public class Battlefield {
	public static final int WIDTH = 16;
	public static final int HEIGHT = 16;
	
	private Game game;
	public Battlefield(Game game) {
		this.game = game;
	}
}
