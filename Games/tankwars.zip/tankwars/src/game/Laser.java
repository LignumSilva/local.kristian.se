/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import org.json.JSONObject;

/**
 *
 * @author Martin
 */
public class Laser {
	private int x0 = 0;
	private int y0 = 0;
	private int x1 = 0;
	private int y1 = 0;
	private int angle = 0;

	// TODO, add projectile owner?
	Tank tank = null;
	
	public Laser(Tank tank) {
		this.tank = tank;
		this.x0 = this.x1 = tank.getX();
		this.y0 = this.y1 = tank.getY();		
		this.angle = tank.getNormalizedAngle();

		if (angle == Tank.ANGLE_DOWN) {
			y0++;
			y1 = Battlefield.HEIGHT-1;
			
		}
		else if (angle == Tank.ANGLE_UP)
		{
			y0--;
			y1 = 0;
		}
		else if (angle == Tank.ANGLE_LEFT)
		{
			x0--;
			x1 = 0;
		}
		else if (angle == Tank.ANGLE_RIGHT) {
			x0++;
			x1 = Battlefield.WIDTH-1;
		}
	}
	
	public void setXTarget(int x) {
		x1 = x;
	}

	public void setYTarget(int y) {
		y1 = y;
	}
	
	
	public JSONObject getJSON() {
		JSONObject obj = new JSONObject();
		obj.put("x0", x0);
		obj.put("y0", y0);
		obj.put("x1", x1);
		obj.put("y1", y1);
		obj.put("angle", angle);
		
		return obj;
	}
		
}
