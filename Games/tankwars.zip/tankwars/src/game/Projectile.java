/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import org.json.JSONObject;

/**
 *
 * @author Martin
 */
public class Projectile {
	private int x0 = 0;
	private int y0 = 0;
	private int angle = 0;
	private int x = 0;
	private int y = 0;
	
	private boolean dead = false;

	// TODO, add projectile owner?
	Tank tank = null;
	
	public Projectile(Tank tank) {
		this.tank = tank;
		this.x0 = this.x = tank.getX();
		this.y0 = this.y = tank.getY();		
		this.angle = tank.getNormalizedAngle();
	}
	
	
	// TODO collision detection..
	public boolean tick() {
		if (angle == Tank.ANGLE_DOWN)
			y++;
		else if (angle == Tank.ANGLE_UP)
			y--;
		else if (angle == Tank.ANGLE_LEFT)
			x--;
		else if (angle == Tank.ANGLE_RIGHT)
			x++;
		
		if (x<0 || x >= Battlefield.WIDTH)
			dead = true;
		else if (y<0 || y >= Battlefield.HEIGHT)
			dead = true;
		
		return !dead;
	}
}
