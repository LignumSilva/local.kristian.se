
package game;
import Webserver.Server;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.UUID;

/**
 * Hold games.
 * @author Martin
 */
public class Game {
	private UUID id;
	private String name;
	private HashMap<UUID, Player> players;
	private boolean started = false;
	private boolean ended = false;
	private JSONArray results = null;
	private Thread simulation = null;
	private long created;
	private Player owner;

	
	public Game(String name) {
		this.name = name;
		this.id = UUID.randomUUID();
		this.players = new HashMap();
		this.created = (new Date()).getTime();
	}
	
	public void start() {
		this.started = true;
		this.simulation = new Thread(new Simulation(this));
		this.simulation.start();
	}
	public void setGameResults(ArrayList<TickTurns> tickTurnsList)
	{
		JSONArray resarr = new JSONArray();
		for (TickTurns tt : tickTurnsList)
		{
			JSONArray jturnarr = new JSONArray();
			resarr.put(jturnarr);
			ArrayList<Turn> ts = tt.getTurns();
			for (Turn turn : ts)
			{
				jturnarr.put(turn.getJSON());
			}
			
		}
		this.results = resarr;
	}
	
	public void setEnded() {
		this.ended = true;
	}
	public Player getOwner() {
		return owner;
	}
	public void setOwner(Player gameOwner) {
		this.owner = gameOwner;
	}
	
	public UUID getId() 
	{
		return id;
	}
	
	public void addPlayer(Player p)
	{
		if (started || ended)
			return;
		
		players.put(p.getUUID(), p);
	}
	
	public void removePlayer(Player p)
	{
		if (started || ended)
			return;

		if (p != null && players.containsKey(p.getUUID()))
			players.remove(p.getUUID());
	}

	public String getName() {
		return name;
	}
	public boolean getStarted() {
		return started;
	}
	public boolean getEnded() {
		return ended;
	}
	
	public HashMap<UUID, Player> getPlayers() {
		return players;
	}
	
	public void handlePlayerFire(Player player)
	{
		
	}
	
	public JSONObject getBattleFieldData() {
		
		JSONObject j = new JSONObject();
		JSONArray arrY = new JSONArray();
		j.put("battleField", arrY);

		for (int y=0; y<Battlefield.HEIGHT; y++)
		{
			JSONArray arrX = new JSONArray();
			arrY.put(arrX);
					
			for (int x=0; x<Battlefield.WIDTH; x++)
			{
				JSONArray arrI = new JSONArray();
				arrX.put(arrI);
			}
		}
				
		ArrayList<Player> players = new ArrayList(this.getPlayers().values());				
		for (Player player : players) {
			Tank tank = player.getTank();
			
			JSONArray ay = arrY.getJSONArray(tank.getY());
			JSONArray ai = ay.getJSONArray(tank.getX());
			ai.put(player.getJSON());
		}
		
		return j;
	}
	
	public JSONObject getJSON() {
		handleTimeouts();
		
		boolean allReady = true;
		JSONArray arr = new JSONArray();
		Collection<Player> plist = this.players.values();
		for(Player p : plist)
		{
			arr.put(p.getJSON());
		}
		
		JSONObject obj = new JSONObject();
		obj.put("name", name);
		obj.put("created", created);
		obj.put("id", id.toString());
		obj.put("players", arr);
		obj.put("started", started);
		obj.put("ended", ended);
		obj.put("canStart", canStart());
		
		if (owner != null)
			obj.put("owner", owner.getId());
		
		if (ended && results != null)
			obj.put("results", results);
		else if (ended && results == null)
		{
			// something went wrong :(
			obj.put("results", new JSONArray());
		}
		
		return obj;
	}
	
	public boolean canStart() {
		boolean allReady = true;
		Collection<Player> plist = this.players.values();
		for(Player p : plist)
		{
			allReady = allReady && p.getReady();
		}
		return (allReady && players.size() > 1);
	}
	
	private void handleTimeouts() {
		if (started)
			return;
		
		Collection<Player> players = this.getPlayers().values();
		long now = (new Date()).getTime();
		for (Player player : players)
		{
			if (now - player.getLastPing() > Player.PLAYER_TIMEOUT)
			{
				// Timeout reached. player hasn't polled in PLAYER_TIMEOUT seconds, make player leave the game.
				System.out.println("Player timed out, making player leave game: " + player + ", game=" + this);
				this.removePlayer(player);
				
				// If owner leaves, clear player list, and later in method, remove game from server is player count = 0
				if (this.owner != null && this.owner.getId() == player.getId())
				{
					if (Server.games.containsKey(this.getId()))
					{
						this.players.clear();						
						break;
					}
				}
			}
		}
		
		if (this.players.isEmpty())
		{
			Server.games.remove(this.getId());
		}
	}
	
	@Override
	public String toString() {
		return "[game, id=" + id.toString() + ", name=" + name + "]";
	}
}
