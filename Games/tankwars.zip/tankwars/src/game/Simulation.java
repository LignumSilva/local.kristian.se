/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import game.command.*;
import gui.Renderer;
import java.util.ArrayList;
import javax.script.*;
import org.json.JSONObject;

/**
 *
 * @author Martin
 */
public class Simulation implements Runnable {
	private static final int maxTicks = 300; // = 300 ticks = 30s
	private Game game;
	public Simulation(Game g)
	{
		this.game = g;
	}
	
	@Override
	public void  run()
	{
		try {
			ScriptEngineManager factory = new ScriptEngineManager();		
			ArrayList<Player> players = new ArrayList(game.getPlayers().values());
			CommandComparator cc = new CommandComparator();
			//Renderer renderer = new Renderer(game);
			ArrayList<TickTurns> gameResults = new ArrayList();

			
			// asign tank colors
			int r = 0;
			int g = 0;
			int b = 1;
			int i = 0;
			
			for (Player player : players) {
				if (i == 0)
					player.getTank().setColor(128,128,255);
				else if (i == 1)
					player.getTank().setColor(128,255,128);
				else if (i == 2)
					player.getTank().setColor(128,255,255);
				else if (i == 3)
					player.getTank().setColor(255,128,128);
				else if (i == 4)
					player.getTank().setColor(255,128,255);
				else if (i == 5)
					player.getTank().setColor(255,255,128);
				
				else {
					player.getTank().setColor(255,255,255);
				}
				i++;
			}
			
			
			for (int tick=0; tick<maxTicks; tick++)
			{
				TickTurns tickTurns = new TickTurns(tick);
				//ArrayList<Turn> tickTurns = new ArrayList();
				ArrayList<ACommand> commands = new ArrayList();
				for (Player player : players) {
					
					if (player.getTank().isDead())
						continue;
					
					JSONObject j = player.tick(game);
					if (j == null)
					{
						// If tank fail, create a NOP command instead.
						//System.out.println("Tank command failed, nooping it. ");
						commands.add(ACommand.createCommand(player, ICommand.TANK_COMMAND_NOP, 0));
						continue;
					}
					
					int cmd = j.getInt("command");
					int cmdVal = j.getInt("value");
					
					//System.out.println(tick + "] Command: " + cmd + "[" + cmdVal + "]");

					ACommand command = ACommand.createCommand(player, cmd, cmdVal);
					commands.add(command);
				}
				
				// order array list. FireCommands first.
				commands.sort(cc);
				
				for (ACommand command : commands) {
					Player player = command.getPlayer();
					Tank tank = player.getTank();					
					int tankAngle = tank.getNormalizedAngle();
					
					if (command instanceof TankFireCommand)
					{	
						if (!handleFireCommand((TankFireCommand)command)) {
							command = ACommand.createCommand(player, ICommand.TANK_COMMAND_NOP, 0);
						} 
					}
					else {
						if (!command.sendTankCommand())
						{
							//System.out.println("Tank command failed, nooping it. " + command);
							command = ACommand.createCommand(player, ICommand.TANK_COMMAND_NOP, 0);
						}
					}
					
					Turn turn = new Turn(tick, player, command.getCommand(), command.getCommandValue());
					tickTurns.add(turn);
					
					tank.resetLaser();
				}
				
				// All commands have been run, update dead status
				for (Player player : players) {
					player.getTank().updateDeadStatus();
				}
				
				gameResults.add(tickTurns);
				//renderer.updateFrame(tickTurns);
			} // end of tick loop

			game.setGameResults(gameResults);
			//renderer.render();
		}
		catch(Exception ex) {
			
		}
		
		game.setEnded();
		//return false;
	}
	
	
	private Player checkFireCollision(Tank tankOrg, int x, int y)
	{
		ArrayList<Player> players = new ArrayList(game.getPlayers().values());
		for (Player player : players) {
			Tank tank = player.getTank();
			if (!tank.isDead() && tank.getX() == x && tank.getY() == y)
			{
				return player;
			}
		}
		
		return null;
	}

	private boolean handleFireCommand(TankFireCommand command)
	{
		Tank tank = command.getPlayer().getTank();
		if (!tank.shoot())
			return false;
		int tankAngle = tank.getNormalizedAngle();
		
		if (tankAngle == Tank.ANGLE_UP)
		{
			// shot into the wall, make some self inflicted damage
			if (tank.getY() == 0)
				tank.setHit(null);
			
			for (int y=tank.getY()-1; y>=0; y--)
			{
				Player otherPlayer = checkFireCollision(tank, tank.getX(), y);
				if (otherPlayer != null)
				{
					// its a hit!
					otherPlayer.getTank().setHit(tank.getLaser());
					break;
				}
			}
		}
		else if (tankAngle == Tank.ANGLE_DOWN)
		{
			// shot into the wall, make some self inflicted damage
			if (tank.getY() == Battlefield.HEIGHT-1)
				tank.setHit(null);

			for (int y=tank.getY()+1; y<Battlefield.HEIGHT; y++)
			{
				Player otherPlayer = checkFireCollision(tank, tank.getX(), y);
				if (otherPlayer != null)
				{
					// its a hit!
					otherPlayer.getTank().setHit(tank.getLaser());
					break;
				}
			}			
		}
		else if (tankAngle == Tank.ANGLE_LEFT)
		{
			// shot into the wall, make some self inflicted damage
			if (tank.getX() == 0)
				tank.setHit(null);

			for (int x=tank.getX()-1; x>=0; x--)
			{
				Player otherPlayer = checkFireCollision(tank, x, tank.getY());
				if (otherPlayer != null)
				{
					// its a hit!
					otherPlayer.getTank().setHit(tank.getLaser());
					break;
				}
			}			
		}
		else if (tankAngle == Tank.ANGLE_RIGHT)
		{
			// shot into the wall, make some self inflicted damage
			if (tank.getY() == Battlefield.WIDTH-1)
				tank.setHit(null);
			
			for (int x=tank.getX()+1; x<Battlefield.WIDTH; x++)
			{
				Player otherPlayer = checkFireCollision(tank, x, tank.getY());
				if (otherPlayer != null)
				{
					// its a hit!
					otherPlayer.getTank().setHit(tank.getLaser());
					break;
				}
			}			
		}
			
		return command.sendTankCommand();
	}
}
