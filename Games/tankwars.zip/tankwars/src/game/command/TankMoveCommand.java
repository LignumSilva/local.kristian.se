package game.command;

import game.Battlefield;
import game.Tank;
import game.Player;

/**
 *
 * @author Martin
 */
public class TankMoveCommand  extends ACommand{

	public TankMoveCommand(Player player, Integer value) {
		super(player, value);
	}

	@Override
	public boolean isValueValid(int value) {
		return (value == 1 || value == -1);
	}

	@Override
	public boolean sendTankCommand() {
		Tank tank = player.getTank();
		if (!this.isValueValid(value))
			return false;
		
		int x = tank.getX();
		int y = tank.getY();
		int a = tank.getNormalizedAngle();
		
		if (this.value == -1) // reverse?
			a = (a + 180) % 360;
		
		switch (a)
		{
			case 0: // Up
				if (y>0)
				{
					tank.setY(y - 1);
					return true;
				}
				break;
				
			case 45: // Up/Right
				if (y>0 && x<Battlefield.WIDTH - 1) 
				{
					tank.setY(y - 1);
					tank.setX(x + 1);
					return true;
				}
				break;
				
			case 90: // Right
				if (x<Battlefield.WIDTH - 1) 
				{
					tank.setX(x + 1);
					return true;
				}
				break;
				
			case 135: // Right/Down
				if (x<Battlefield.WIDTH - 1 && y < Battlefield.HEIGHT - 1) 
				{
					tank.setX(x + 1);
					tank.setY(y + 1);
					return true;
				}
				break;
				
			case 180: // DOWN
				if (y < Battlefield.HEIGHT - 1) 
				{
					tank.setY(y + 1);
					return true;
				}
				
				break;
				
			case 225: // LEFT/DOWN
				if (x > 0 && y < Battlefield.HEIGHT - 1) 
				{
					tank.setY(y + 1);
					tank.setX(x - 1);
					return true;
				}

				break;
				
			case 270:	// LEFT
				if (x > 0) 
				{
					tank.setX(x - 1);
					return true;
				}
				
				break;
				
			case 315: // LEFT UP
				if (x > 0 && y > 0) 
				{
					tank.setY(y - 1);
					tank.setX(x - 1);
					return true;
				}

				break;				
		}
		
		return false;
	}
	
	@Override
	public String toString() {
		return "TankMoveCommand["+value+"]";
	}	
}
