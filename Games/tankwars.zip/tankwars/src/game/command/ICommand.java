/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game.command;

import game.Tank;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Martin
 */
public interface ICommand {	
	
	public static final int TANK_COMMAND_FIRE = 0;			// Fire turret
	public static final int TANK_COMMAND_MOVE = 1;			// Move tank 1 square. Valid values are 1 and -1.
	public static final int TANK_COMMAND_ROTATE = 2;			// Turn tank. Valid values 0, 45, 90, 135, 180, -45, -90, -135, -180
	
	public static final int TANK_COMMAND_NOP = 1000;
	
	public boolean isValueValid(int value);
	public boolean sendTankCommand();
	public int getCommand();
	public int getCommandValue();
}
