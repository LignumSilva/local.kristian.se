/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game.command;

import game.Tank;
import game.Player;
/**
 *
 * @author Martin
 */
public class TankFireCommand extends ACommand {

	public TankFireCommand(Player player, Integer value) {
		super(player, value);
	}

	@Override
	public boolean isValueValid(int value) {
		return true;
	}	

	@Override
	public boolean sendTankCommand() {
		Tank tank = player.getTank();
		if (tank.getAmmo() <= 0)
			return false;
		
		tank.setAmmo(tank.getAmmo() - 1);
		return true;
	}
	
	@Override
	public String toString() {
		return "TankFireCommand["+value+"]";
	}
}
