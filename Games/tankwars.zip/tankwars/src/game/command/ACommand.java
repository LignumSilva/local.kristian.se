/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game.command;

import game.Player;
import game.Player;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Martin
 */
public abstract class ACommand implements ICommand {
	protected Integer value;
	protected Player player;
	
	public static ACommand createCommand(Player player, int command, int value)
	{
		switch(command) 
		{
			case ICommand.TANK_COMMAND_FIRE: 
				return new TankFireCommand(player, value); 
			case ICommand.TANK_COMMAND_ROTATE: 
				return new TankRotateCommand(player, value);
			case ICommand.TANK_COMMAND_MOVE: 
				return new TankMoveCommand(player, value);
			case ICommand.TANK_COMMAND_NOP: 
				return new TankNOPCommand(player, value);
			
		}
		return null;
	}
	
	public ACommand(Player player, Integer value)
	{
		this.value = value;
		this.player = player;
	}
	
	public Player getPlayer() {
		return player;
	}
	
	@Override
	public int getCommand() {
		if (this instanceof TankFireCommand)
			return ICommand.TANK_COMMAND_FIRE;
		else if (this instanceof TankRotateCommand)
			return ICommand.TANK_COMMAND_ROTATE;
		else if (this instanceof TankMoveCommand)
			return ICommand.TANK_COMMAND_MOVE;
		else if (this instanceof TankNOPCommand)
			return ICommand.TANK_COMMAND_NOP;
		
		return -1;
	}
	
	@Override
	public int getCommandValue() {
		return value;
	}
	
}
