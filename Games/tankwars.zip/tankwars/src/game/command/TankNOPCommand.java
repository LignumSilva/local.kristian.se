package game.command;

import game.Battlefield;
import game.Tank;
import game.Player;

/**
 *
 * @author Martin
 */
public class TankNOPCommand  extends ACommand{

	public TankNOPCommand(Player player, Integer value) {
		super(player, value);
	}

	@Override
	public boolean isValueValid(int value) {
		return true;
	}

	@Override
	public boolean sendTankCommand() {
		return true;
	}
	
	@Override
	public String toString() {
		return "TankNOPCommand[]";
	}	
}
